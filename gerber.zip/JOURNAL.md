---
title: "WASP"
author: "Haroki"
description: "Wi-Fi sensing platform using bunch of ESP32!"
created_at: "2025-06-25"
---
